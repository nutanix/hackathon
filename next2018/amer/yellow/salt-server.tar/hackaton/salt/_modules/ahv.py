"""
Acropolis execution module
:maintainer: Wilson Santos (wss@slb.com)
:depends: acropolis
:platform: all
"""

from __future__ import absolute_import
import logging
import time

try:
    import acropolis
    HAS_ACROPOLIS = True
except ImportError as e:
    HAS_ACROPOLIS = False


LOG = logging.getLogger(__name__)


def __virtual__():
    if 'foundation' in __pillar__ and HAS_ACROPOLIS:
        if 'hypervisors' in __pillar__['foundation']:
            return 'ahv'
        else:
            return False, '`hypervisors` parameter not found in foundation pillar.'
    else:
        if not HAS_ACROPOLIS:
            return False, '`acropolis` module not found.'
        else:
            return False, '`foundation:hypervisors` pillar not found.'


def _connect(hypervisor_profile='default', host=None, port=None, username=None, password=None):
    """
    Creates a connection to the hypervisor.

    Args:
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor.
            If none is given, `host`, `port`, `username` and `password` arguments will be required.
        host (str): Hypervisor address.
        port (int): Which port to connect to the hypervisor
        username (str): Username to connect to the acropolis REST API.
        password (str): Password to connect to the acropolis REST API.

    Returns:
        acropolis.Acropolis
    """
    
    pillar_params = {}
    if hypervisor_profile:    
        pillar_params =  __pillar__['foundation']['hypervisors'][hypervisor_profile]

    conn = acropolis.Acropolis(
        host=host or pillar_params['host'],
        port=port or pillar_params['port'],
        user=username or pillar_params['username'],
        passwd=password or pillar_params['password']
    )
    
    return conn


def vm_create(vm_name, image, nic, vcpus=1, cores_per_vcpu=1, memory=4096, disk_size=None, user_data=None,
              hypervisor_profile='default'):
    """

    Creates a Virtual Machine

    Args:
        vm_name (str): The name of the VM
        image (str): The image disk name
        nic (str): The network interface name
        vcpus (int): Amount of VCPUs
        cores_per_vcpu: Amount of cores per VCPUs
        memory (int): Amount of RAM in MB
        disk_size (int): The size of the hard disk (in GB). If not specified it will use the image default.
        user_data (str): The data to be use with cloud-init or Sysprep.
        hypervisor_profile: The hypervisor profile contained within the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        dict
    """

    vm_params = {
        'num_vcpus': vcpus,
        'num_cores_per_vcpu': cores_per_vcpu,
        'memory_mb': memory
    }

    LOG.debug('Creating {} VM: {}'.format(vm_name, vm_params))

    ret = {
        vm_name: {}
    }
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    res = vm.create(
        image=acropolis.Image(acrop, name=image),
        network=acropolis.Network(acrop, name=nic),
        params=vm_params,
        userdata=user_data,
        power_on=True,
        disk_size=disk_size
    )

    ret[vm_name]['vm_created'], ret[vm_name]['vm_powered_on'] = res
    LOG.debug(ret)
    return '{} creation {}.'.format(vm_name, ret[vm_name]['vm_created'])


def vm_restore(vm_name, snapshot_name=None, hypervisor_profile='default'):
    """
    Restores a Virtual Machine to a specific snapshot

    Args:
        vm_name (str): The VM name
        snapshot_name (str): The name of the snapshot to be restored
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        dict
    """

    LOG.debug('Restoring {} VM'.format(vm_name))

    ret = {
        vm_name: {}
    }

    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    # TODO fix return  object
    ret[vm_name]['vm_restored'], ret[vm_name]['vm_powered_on'] = vm.restore(snapshot_name)
    LOG.debug(ret)
    return ret


def vm_delete(vm_name, hypervisor_profile='default'):
    """
    Delete a Virtual Machine

    Args:
        vm_name (str): The VM name
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        str
    """

    LOG.debug('Removing {} VM'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    ret = vm.delete()
    LOG.debug(ret)
    if ret:
        return ret == 'Succeeded'


def vm_exists(vm_name, hypervisor_profile='default'):
    """
    Checks if a Virtual Machine with the specified name exists

    Args:
        vm_name (str): The VM name
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        bool
    """
    LOG.debug('Checking if {} exists'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    return vm.exists()


def vm_create_snapshot(vm_name, snapshot_name, hypervisor_profile='default'):
    """
    Creates a snapshot of the Virtual Machine

    Args:
        vm_name (str):
        snapshot_name:
        hypervisor_profile:

    Returns:

    """
    LOG.debug('Creating {} snapshot'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    return vm.create_snapshot(snapshot_name)

def vm_is_on(vm_name, hypervisor_profile='default'):
    """
    Checks if a Virtual Machine is on or off

    Args:
        vm_name (str): The VM name
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        bool: True if the virtual machine is powered or False otherwise
    """

    LOG.debug('Check status of vm {}'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    return vm.is_on()


def vm_power_off(vm_name, async=False,  force=False, hypervisor_profile='default'):
    """
    Powers off a Virtual Machine

    Args:
        vm_name (str): The VM name
        async (bool, optional): If set to `True` it will not wait for the power off task to complete.
        timeout (str, optional): If async is set to true, this is the time in seconds to wait for the task to complete. Default value 10 seconds
        force (bool, optional): If set to `True`, vm will be forced to shut down
        force_after_timeout (bool, optional): If set to true, force shutdown command will be sent after timeout expires
        hypervisor_profile (str, optional): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar
    
    Returns:
        bool: True indicates power off success
    """
    LOG.debug('Powering off {}'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    ret = vm.power_off(async, force)
    return ret


def vm_power_on(vm_name, async=False, hypervisor_profile='default'):
    """
    Powers on a Virtual Machine

    Args:
        vm_name (str): The VM name
        async (bool, optional): If set to `True` it will not wait for the power on task to complete.
        timeout (str, optional): If async is set to true, this is the time in seconds to wait for the task to complete. Default value 10 seconds
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar

    Returns:
        bool: True indicates power on success

    """
    LOG.debug('Powering on {}'.format(vm_name))
    acrop = _connect(hypervisor_profile)
    vm = acropolis.VirtualMachine(acrop, name=vm_name)
    ret = vm.power_on(async)
    return ret
    


def cluster_shutdown(hypervisor_profile='default', sleep=120, force=False, reboot=False):
    """
    Shutdown all cluster VMs except the one running this minion, stop all cluster services and
    shuts down all controller VMs.

    Args:
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar.
        sleep (int): For how long to sleep before running the cluster shutdown.
            Useful for giving enough time for the minion that is triggering the procedure, to shutdown itself.
        force (bool): Whether or not to force cluster shutdown, skipping graceful VM shutdown.
        reboot (bool): Whether or not to reboot the cluster after shutdown.

    Returns:

    """
    this_minion_id = __salt__['grains.get']('id')

    LOG.warning('Cluster shutdown procedure initiated.')

    acrop = _connect(hypervisor_profile)
    cluster = acropolis.Cluster(acrop)

    LOG.warning('Stopping salt schedules...')
    __salt__['schedule.disable']()

    LOG.warning('Triggering cluster shutdown.')
    cluster.shutdown(
        sleep=sleep,
        force=force,
        outcast=this_minion_id,
        reboot=reboot
    )

    LOG.info('Restoring salt schedules...')
    __salt__['schedule.enable']()

    LOG.warning('Shutting down {}...'.format(this_minion_id))
    __salt__['system.poweroff']()


def cluster_tmux_cmd(cmd, hypervisor_profile='default', sleep=0):
    """
    Execute command on controller VM using tmux

    Args:
        cmd (str): The command to be executed
        hypervisor_profile (str): The hypervisor profile contained withing the foundation:hypervisors pillar that
            specifies how to connect to a Acropolis hypervisor. If none is given it will look for the parameters inside
            the hypervisors:default pillar.
        sleep (int): Amount of time in seconds to wait before executing the command inside the tmux session.

    Returns:
        tuple
    """
    acrop = _connect(hypervisor_profile)
    cluster = acropolis.Cluster(acrop)
    return cluster.tmux_cmd(cmd=cmd, sleep=sleep)
